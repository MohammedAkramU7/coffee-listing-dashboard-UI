import React, { useEffect, useState } from "react";
import img from "../assets/img/vector.svg"

const Card = () => {
  const [coffeeData, setCoffee] = useState([]);
  const [filter, setFilter] = useState("all");

  useEffect(() => {
    fetch(
      "https://raw.githubusercontent.com/devchallenges-io/curriculum/refs/heads/main/4-frontend-libaries/challenges/group_1/data/simple-coffee-listing-data.json"
    )
      .then((response) => response.json())
      .then((data) => {
        setCoffee(data);
      })
      .catch((error) => {
        console.error("Error fetching coffee data:", error);
      });
  }, []);
  
  const filteredData = coffeeData.filter((ele) => 
    filter === "available" ? ele.available === true : true
  );  

  return (
    <div className="bg-[#1B1D1F] max-w-5xl w-256 mt-10 p-10 text-white text-center rounded-lg shadow-lg relative">
      <img src={img} className="absolute" ></img>
      

      
      {/* Heading Section */}
      <div className="mb-6">
        <h1 className="text-3xl font-semibold">Our Collection</h1>
        <p className="text-[#4D5562] text-base mt-2">
          Introducing our Coffee Collection, a selection of unique coffee <br/> from
          different roast types and origins, expertly roasted in small <br/> batches
          and shipped fresh weekly.
        </p>
      </div>
      <div className="mb-6 flex justify-center space-x-4">
        <button
          className={`cursor-pointer px-4 py-2 rounded ${
            filter === "all" ? "bg-[#6F757C] text-white" : "bg-gray-300 text-[#111315]" 
          }`}
          onClick={() => setFilter("all")}
        >
          All Products
        </button>
        <button
          className={`cursor-pointer px-4 py-2 rounded ${
            filter === "available" ? "bg-[#6F757C] text-white" : "bg-gray-300 text-[#111315]"
          }`}
          onClick={() => setFilter("available")}
        >
          Available Products
        </button>
      </div>

      {/* Coffee Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {filteredData.map((ele, id) => (
          <div key={id} className=" relative p-4 text-center">
            {ele.popular && (
                <div className="absolute top-5 left-12 bg-red-500 text-white text-xs font-bold p-[3px] rounded">
                  Popular
                </div>
              )}
            
            <img
              className="w-54 h-34 mx-auto object-cover rounded-[12px]"
              src={ele.image}
              alt={ele.name}
            />
            <div className="flex items-center justify-center space-x-2 gap-13">
            <h5 className="text-lg font-semibold mt-2">{ele.name}</h5>
            <div className="text-[#111315] bg-[#BEE3CC] rounded-[4px] text-[12px] p-[4px]">{ele.price}</div>
            </div>
            <div className="flex items-left justify-center space-x-2 text-gray-400">
  <p className="text-white">⭐{ele.rating}</p>
  <p>({ele.votes} votes)</p>
  {!ele.available && (
    <div className="text-[#FF0000] font-semibold"> sold out</div>
  )}
</div>
            
          </div>
        ))}
      </div>
    </div>
  );
};

export default Card;
