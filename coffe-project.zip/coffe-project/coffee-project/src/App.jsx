import React from "react";
import image from "./assets/img/bg-cafe.jpg";
import Card from "./Component/Card";

const App = () => {
  return (
    <div className="relative w-full h-screen">
      {/* Background Image */}
      <div
        className="absolute w-full h-full bg-top bg-repeat-x z-0"
        style={{ backgroundImage: `url(${image})` }}
      ></div>

      {/* Card Component (Above Background) */}
      <div className="absolute top-2/3 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-10">
        <Card />
      </div>
    </div>
  );
};

export default App;
